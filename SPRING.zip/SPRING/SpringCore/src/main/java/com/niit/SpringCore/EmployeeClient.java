package com.niit.SpringCore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class EmployeeClient {

	public static void main(String[] args) {		
		// Jav traditional Way		
		Employee eRef = new Employee();
		eRef.setEid(100);
		eRef.setEname("Gaurav");
		//eRef.setEaddress("Red Wood Shores");
		
		System.out.println("Employee Details :" +eRef);
		
		// Spring Way | IOC (Inversion Of Control)		
		// we User will not create Objects, instead IOC Container will create
		// We are just configuring the Objects
		Resource res = new ClassPathResource("EmployeeBean.xml");
		BeanFactory factory=new XmlBeanFactory(res); // api . Spring Container used to run 
		 //single applications
		// will parse xml files & create objects.
		
		//another way to run multiple applications
		//ApplicationContext factory = new ClassPathXmlApplicationContext("EmployeeBean.xml");
		//ApplicationContext context = new ClassPathXmlApplicationContext("EmployeeBean.xml");

		// 2 ways of using getBean Method
		Employee e1 = (Employee)factory.getBean("emp1");
		//Employee e2 = factory.getBean("emp2", Employee.class);
		//Employee e1 = (Employee)context.getBean("emp1");
		
		System.out.println("Employee Details : " + e1);
		//System.out.println("Employee Details : " + e2);
	}
}
