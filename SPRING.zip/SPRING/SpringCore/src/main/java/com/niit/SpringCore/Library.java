package com.niit.SpringCore;

import java.util.List;

public class Library {
	
	private List stringList;
	private List bookList;
	public List getStringList() {
		return stringList;
	}
	public void setStringList(List stringList) {
		this.stringList = stringList;
	}
	public List getBookList() {
		return bookList;
	}
	public void setBookList(List bookList) {
		this.bookList = bookList;
	}
}
